# Art & Mind, Inc.

Art & Mind, Inc. is a 501(c)(3) not-for-profit corporation based in Decatur, GA.
We provide community service programs focused on creativity, wellness, and education.

## Features
- Website with About, Programs, Contact
- Volunteer, Donation, and Feedback forms
- Analytics dashboard for community data

## Deployment
This repo is set up to deploy via GitHub Pages using GitHub Actions.
