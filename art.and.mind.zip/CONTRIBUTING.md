# Contributing

Thank you for your interest in contributing to Art & Mind, Inc.!

- Fork the repo and create feature branches
- Submit pull requests for review
- Follow coding style and documentation practices
